# Check of arXiv:2408.07175v3

**Evolving Dark Energy or Supernovae Systematics?** — G. Efstathiou. MNRAS 538 (2025) 875-882. [arXiv:2408.07175v3](https://arxiv.org/abs/2408.07175v3).

**Result: Reproduced, with notes (checked scope).** We rebuilt the paper's supernova analysis with our own code: fits of ΛCDM and w0waCDM to the Pantheon+ and DES5Y catalogues, the magnitude comparison of supernovae common to both, the effect of subtracting 0.04 mag from the DES5Y low-redshift supernovae, and the appendix comparison with DESI DR1 BAO. The checked conclusions reproduce within the declared tolerances, using the inferred distance convention and the stated prior variants; numerical exceptions are listed below. The central measurement holds: supernovae common to both catalogues show a low-redshift minus DES offset of −0.036 mag. With the 0.04 mag shift, DES5Y no longer prefers evolving dark energy (1.19σ). We list four small points that change no conclusion and six presentation slips as notes. This is a scoped reproduction, not a certification of the entire paper.

> **Draft, not released.** Unreleased candidate; approval is recorded separately for its exact manifest and archive.

## What we checked

- Sample selection and counts for Pantheon+ and DES5Y (C1)
- χ² of the Planck ΛCDM cosmology and the ΛCDM fits to both catalogues (C2)
- The w0waCDM fits and their χ² improvements (C3)
- The significance statements in the text and abstract (C4)
- The supernova-only posteriors and where Planck ΛCDM lies in them (C5)
- Table 1: the magnitude offsets of supernovae common to both catalogues, and the low-redshift minus DES difference (C6)
- DES5Y with 0.04 mag subtracted from its low-redshift supernovae: fits and posterior (C7)
- Appendix A: DESI DR1 BAO alone and combined with each supernova catalogue (C8)
- Numbers quoted from Planck 2018, DESI 2024 and the DES analysis of the offset (Vincenzi et al. 2025) (C9)

**Not checked:**

- Whether the offset seen in the common supernovae implies a calibration error in the full DES5Y sample. That needs the light curves, bias-correction simulations and cross-catalogue systematic covariance, which the public distance tables do not carry. The paper's 'can bring … into good agreement' is conditional, and the shift experiment supports it
- The DES analysis's own decomposition of the offset (selection, host-mass and intrinsic-scatter terms), beyond checking that the quoted numbers match their source
- The statement that binned and unbinned likelihoods give nearly identical results (l.257), and the attribution of the remaining asymmetry of the shifted posterior to supernovae at z > 1 (l.425–426)
- The paper's own chains and plotting settings, which are not public. Our posteriors are grids over the prior box; for the Pantheon+ posterior we used a w_a range that contains the plotted contours (note N2)
- The ± 0.008 mag on the offset is the scatter of the common supernovae only, without correlated systematic errors between the catalogues, so it is not a calibrated significance

## Claims (9 checked, 4 reproduced within tolerance)

| Claim | Where | Result | Output |
|---|---|---|---|
| C1 | l.198, 208, 232, 257-259 | Reproduced | [`checks/out/fits.out`](checks/out/fits.out) |
| C2 | l.259-260, 266-270, 279-281; Fig. 1 legends | Reproduced, under the inferred distance convention (N1) | [`checks/out/fits.out`](checks/out/fits.out) |
| C3 | l.271-274, 281-287; Fig. 1 legends | Reproduced; the printed best-fit points sit slightly above the minima (N3) | [`checks/out/fits.out`](checks/out/fits.out) |
| C4 | l.280, 289-290; abstract l.92-93 | Reproduced | [`checks/out/fits.out`](checks/out/fits.out) |
| C5 | l.297-321, Fig. 2; priors l.299-304 | Reproduced with a w_a prior range that contains the plotted contours; the printed range cannot have been used (N2) | [`checks/out/posteriors.out`](checks/out/posteriors.out) |
| C6 | l.340-353, 388-393, Table 1 (l.519-528), Fig. 4 | Counts, means and the offset reproduced; two error entries, three median redshifts and one count require the notes: N4, N5, N6 | [`checks/out/crossmatch.out`](checks/out/crossmatch.out) |
| C7 | l.414-426, Fig. 5 legends, Fig. 6; l.563-567 | Conclusion reproduced; the printed best fit is not the minimum, so the χ² gain is 2.89, not 2.3 (N7) | [`checks/out/fits.out`](checks/out/fits.out) |
| C8 | Appendix A (l.648-658), Fig. 8 | Qualitative pattern reproduced; the H0 prior is unstated and one level depends on it (N10) | [`checks/out/posteriors.out`](checks/out/posteriors.out) |
| C9 | l.133, 139-140, 167-168, 469-480, 657 | 12 of 13 quoted numbers match their sources; one decimal-place error and one comparison of differently defined offsets: N8, N9 | [`checks/out/c9_citations.out`](checks/out/c9_citations.out) |

PROTOCOL.md is a public edition of the dated scientific plan and amendments, with internal role descriptions omitted. Scientific criteria and the record of post-hoc choices are preserved; the original is retained privately. Release replay gates in VALIDATION.md are separate post-hoc engineering checks; they do not erase scientific exceptions. Printed inputs are in paper_values.json.

## Notes

- **N1** (S0, Sect. 2, Figs 1 and 5). The paper does not state how it converts redshift to luminosity distance. At the six printed best-fit points in Figs 1 and 5, χ² agrees within approximately 0.071 with D_L = (1+z_HD) D_C(z_HD). The Planck-point χ² differences are 0.078 for Pantheon+ and 0.141 for DES5Y. Of the two tested conventions, this one reproduces the printed fits more closely; the author's implementation is not known. With the (1+z_HEL) factor used by the Pantheon+ and DES releases they are missed by up to 0.85, and the DES5Y Δχ² between the Planck point and the ΛCDM fit becomes 5.49 instead of 4.93. No conclusion changes. We judged every claim under this inferred convention and report the other beside it. [`checks/out/fits.out`](checks/out/fits.out)
- **N2** (S0, l.299–302, Fig. 2). The printed Pantheon+ prior range −4 ≤ w_a ≤ −0.4 excludes w_a = 0, so it cannot contain the Planck point the text places inside the 1σ contours. It also excludes the paper's own Pantheon+ best fit (w_a = 0.18). Fig. 2's Pantheon+ contours extend from w_a = −6 (the axis edge) to about +1.9. With w_a in [−10, 2], a range that contains them, the Planck point lies at the 0.43, 0.38 and 0.07 levels in the three projections, inside 1σ as stated. The printed range is a slip; the settings actually used are not known. [`checks/out/posteriors.out`](checks/out/posteriors.out)
- **N3** (S0, Fig. 1 legends). The printed w0waCDM best-fit points are not exact minima: their χ² is 0.14 (Pantheon+) and 0.15 (DES5Y) above ours, along the shallow w0–w_a direction. The printed χ² improvements are within our tolerance. [`checks/out/fits.out`](checks/out/fits.out)
- **N4** (S0, Table 1). The errors on the DES and Foundation means are printed as ± 0.0006 and ± 0.0007. Using the sample standard deviation (ddof = 1), the scatter of the common supernovae gives standard errors of 0.0056 and 0.0071, as printed in the linked output. The text gives ± 0.007 for Foundation (l.391) and Fig. 4 draws the right error bars, so the table entries appear to be decimal-place typos. They do not enter our cosmological fits; the author's code is unavailable. [`checks/out/crossmatch.out`](checks/out/crossmatch.out)
- **N5** (S0, Table 1). The median redshifts printed for CFA3S, CFA4P3 and CSP (0.037, 0.033, 0.038) are not reproduced by any redshift column of either catalogue; we get 0.034, 0.039 and 0.044. The other rows match within 0.002. The column is descriptive. [`checks/out/c6_zmedian.out`](checks/out/c6_zmedian.out)
- **N6** (S0, l.389). The text says 150 Foundation supernovae are in Pantheon+. There are 179 rows, and 152 within the paper's redshift cut on z_HD; a cut on z_CMB gives exactly 150. The 118 supernovae in both catalogues, the ones used, are unaffected. [`checks/out/crossmatch.out`](checks/out/crossmatch.out)
- **N7** (S1, Fig. 5 legends, l.414–426). For DES5Y with 0.04 mag subtracted from its low-redshift supernovae, the printed w0waCDM point (Ω_m, w0, w_a) = (0.426, −1.068, −2.63) is 0.55 in χ² above the minimum at (0.457, −0.901, −5.271). The χ² gain over ΛCDM is therefore 2.89, against 2.3 implied by the two χ² values in the legend and 2.5 in the text. The conclusion holds: 2.89 for two parameters is 1.19σ, no significant preference. [`checks/out/fits.out`](checks/out/fits.out)
- **N8** (S1, l.657). The text quotes Ω_m = 0.0344 for DESI BAO with Planck in w0waCDM; the DESI 2024 paper's DESI+CMB row gives 0.344 (+0.032, −0.027). Here CMB includes Planck temperature and polarization data and Planck+ACT lensing. The corrected value supports the same sentence: it still disfavours the high Ω_m (median 0.475) that DES5Y alone prefers. [`checks/out/c9_citations.out`](checks/out/c9_citations.out)
- **N9** (S1, l.469–472). The paper calls the DES analysis's −0.042 mag an offset between DES supernovae and 'low redshift SN common to both catalogues', consistent with its own. In that analysis −0.042 is an inverse-variance-weighted Foundation minus DES difference over 118 and 145 supernovae. The paper's own −0.036 is an unweighted difference over all 187 low-redshift supernovae; the unweighted Foundation minus DES is −0.039. The two numbers are consistent, but they are not the same quantity. [`checks/out/crossmatch.out`](checks/out/crossmatch.out)
- **N10** (S1, Appendix A, l.650). Appendix A states the prior on the sound horizon r_d but not the one on H0, and the BAO distance scale depends on both. With a flat H0 prior in [20, 100], every appendix statement holds: DESI + Pantheon+ puts the Planck point at the 0.61, 0.42 and 0.74 levels ('touches the 1σ contours'), and DESI + DES5Y puts ΛCDM at 2.70σ. With the Planck H0 prior these become 0.63, 0.34 and 0.84, and 2.71σ. The broad conclusion remains similar, but the 0.84 level under the alternate prior exceeds the protocol's 0.80 gate for 'touches the 1σ contours'; the primary prior passes that gate. These are qualitative contour comparisons, not a claim that every level is inside 68.27%. Which prior was used changes one level by 0.1. Under the protocol's fixed rule this is S0; it is reported as S1 because the setting is needed to reproduce the figure. [`checks/out/posteriors.out`](checks/out/posteriors.out)

**Context.** Later work by the DES collaboration (DES-Dovekie, arXiv:2511.07517) corrected parts of the DES5Y calibration; that does not by itself show that a uniform 0.04 mag shift is the right correction.

## Newer data

- **M1** (DES-Dovekie). With the recalibrated DES 5-year sample, the offset of the common supernovae against Pantheon+ is unchanged at −0.0363 ± 0.0082 mag (crossmatch.out). The supernova-only preference for evolving dark energy drops: the χ² gain of w0waCDM over ΛCDM is 5.62 instead of 7.61 (fits.out), and the Planck point lies at 2.0–2.2σ instead of 2.3–2.8σ in the three projections. [`checks/out/posteriors.out`](checks/out/posteriors.out)
- **M2** (DESI DR2 BAO). With DESI DR2 instead of DR1, ΛCDM lies at 3.09σ in w0–w_a with DES5Y, 2.00σ with DES-Dovekie and 1.59σ with Pantheon+. These are BAO plus supernovae without the CMB, so they are not comparable with published results that include it. [`checks/out/posteriors.out`](checks/out/posteriors.out)

A re-test on newer data describes how the model fares; it does not change whether the paper's own work reproduces.

## Datasets

| Dataset | Release | Role | Used for | Links |
|---|---|---|---|---|
| Pantheon+ supernovae: data file and STAT+SYS covariance | 2022 | data the paper used | C1, C2, C3, C5, C6, C8, M1, M2 | [source](https://github.com/PantheonPlusSH0ES/DataRelease) · [The Pantheon+ analysis](https://arxiv.org/abs/2202.04077) · [Pantheon+SH0ES.dat](https://raw.githubusercontent.com/CobayaSampler/sn_data/61d96434cafc2770928322c38e5a750e686368ae/PantheonPlus/Pantheon+SH0ES.dat) · [Pantheon+SH0ES_STAT+SYS.cov](https://raw.githubusercontent.com/CobayaSampler/sn_data/61d96434cafc2770928322c38e5a750e686368ae/PantheonPlus/Pantheon+SH0ES_STAT+SYS.cov) · [config.dataset](https://raw.githubusercontent.com/CobayaSampler/sn_data/61d96434cafc2770928322c38e5a750e686368ae/PantheonPlus/config.dataset) |
| DES 5-year supernovae (Vincenzi et al. 2024, original calibration): Hubble diagram and systematic covariance | SN5YR (2024) | data the paper used | C1, C2, C3, C4, C5, C6, C7, C8 | [source](https://github.com/des-science/DES-SN5YR/releases/tag/1.3) · [DES](https://arxiv.org/abs/2401.02929) · [DES-SN5YR_HD.csv](https://raw.githubusercontent.com/CobayaSampler/sn_data/61d96434cafc2770928322c38e5a750e686368ae/DESY5/DES-SN5YR_HD.csv) · [covsys_000.txt](https://raw.githubusercontent.com/CobayaSampler/sn_data/61d96434cafc2770928322c38e5a750e686368ae/DESY5/covsys_000.txt) · [config.dataset](https://raw.githubusercontent.com/CobayaSampler/sn_data/61d96434cafc2770928322c38e5a750e686368ae/DESY5/config.dataset) |
| DESI DR1 BAO distances (Gaussian likelihood, all tracers) | DR1 (2024) | data the paper used | C8 | [source](https://data.desi.lbl.gov/doc/releases/dr1/) · [DESI DR1 data release paper](https://arxiv.org/abs/2503.14745) · [DESI 2024 III](https://arxiv.org/abs/2404.03000) · [DESI 2024 IV](https://arxiv.org/abs/2404.03001) · [DESI 2024 VI](https://arxiv.org/abs/2404.03002) · [desi_2024_gaussian_bao_ALL_GCcomb_mean.txt](https://raw.githubusercontent.com/CobayaSampler/bao_data/bb0c1c9009dc76d1391300e169e8df38fd1096db/desi_2024_gaussian_bao_ALL_GCcomb_mean.txt) · [desi_2024_gaussian_bao_ALL_GCcomb_cov.txt](https://raw.githubusercontent.com/CobayaSampler/bao_data/bb0c1c9009dc76d1391300e169e8df38fd1096db/desi_2024_gaussian_bao_ALL_GCcomb_cov.txt) |
| DES-Dovekie supernovae (DES 5-year with Dovekie recalibration): Hubble diagram and STAT+SYS covariance | DES-Dovekie (2025/2026) | newer release of the paper's data | M1, M2 | [source](https://github.com/des-science/DES-SN5YR) · [Popovic et al. 2026, DES SN reanalysis with Dovekie calibration](https://arxiv.org/abs/2511.07517) · [Popovic et al. 2025b, Dovekie calibration](https://arxiv.org/abs/2506.05471) · [DES-Dovekie_HD.csv](https://raw.githubusercontent.com/des-science/DES-SN5YR/c9a4fcafc4cbd19bd750dee47fc76194a45c181f/4_DISTANCES_COVMAT/DES-Dovekie_HD.csv) · [STAT+SYS.npz](https://raw.githubusercontent.com/des-science/DES-SN5YR/c9a4fcafc4cbd19bd750dee47fc76194a45c181f/4_DISTANCES_COVMAT/STAT+SYS.npz) · [STATONLY.npz](https://raw.githubusercontent.com/des-science/DES-SN5YR/c9a4fcafc4cbd19bd750dee47fc76194a45c181f/4_DISTANCES_COVMAT/STATONLY.npz) |
| DESI DR2 BAO distances (Gaussian likelihood, all tracers) | DR2 (2025) | newer release of the paper's data | M2 | [source](https://data.desi.lbl.gov/public/papers/y3/bao-cosmo-params/README.html) · [DESI DR2 Results II](https://arxiv.org/abs/2503.14738) · [DESI DR2 Results I](https://arxiv.org/abs/2503.14739) · [desi_gaussian_bao_ALL_GCcomb_mean.txt](https://raw.githubusercontent.com/CobayaSampler/bao_data/bb0c1c9009dc76d1391300e169e8df38fd1096db/desi_bao_dr2/desi_gaussian_bao_ALL_GCcomb_mean.txt) · [desi_gaussian_bao_ALL_GCcomb_cov.txt](https://raw.githubusercontent.com/CobayaSampler/bao_data/bb0c1c9009dc76d1391300e169e8df38fd1096db/desi_bao_dr2/desi_gaussian_bao_ALL_GCcomb_cov.txt) |
| Planck CamSpec (12.5cln TTTEEE) LCDM parameters | PR3 maps, CamSpec reanalysis (Efstathiou & Gratton 2021) | published value, taken as printed | C2, C3, C4, C5, C7, C8 | [source](https://arxiv.org/abs/1910.00483) · [Efstathiou & Gratton 2021, CamSpec likelihood and reanalysis of the Planck high-frequency maps](https://arxiv.org/abs/1910.00483) |
| DESI 2024 (DR1) cosmological constraints | DR1 (2024) | published value, taken as printed | C9 | [source](https://arxiv.org/abs/2404.03002) · [DESI 2024 VI](https://arxiv.org/abs/2404.03002) |
| Planck 2018 ΛCDM parameters | PR3 (2018) | published value, taken as printed | C9 | [source](https://pla.esac.esa.int/) · [Planck 2018 results VI](https://arxiv.org/abs/1807.06209) |
| DES-SN5YR vs Pantheon+ offset inventory (Vincenzi et al. 2025) | SN5YR (2024) comparison | published value, taken as printed | C9 | [source](https://arxiv.org/abs/2501.06664) · [Vincenzi et al. 2025, Comparing the DES-SN5YR and Pantheon+ SN cosmology analyses](https://arxiv.org/abs/2501.06664) |

**DESI DR1 BAO distances (Gaussian likelihood, all tracers); DESI DR2 BAO distances (Gaussian likelihood, all tracers).** This research used data obtained with the Dark Energy Spectroscopic Instrument (DESI). DESI construction and operations is managed by the Lawrence Berkeley National Laboratory. This material is based upon work supported by the U.S. Department of Energy, Office of Science, Office of High-Energy Physics, under Contract No. DE–AC02–05CH11231, and by the National Energy Research Scientific Computing Center, a DOE Office of Science User Facility under the same contract. Additional support for DESI was provided by the U.S. National Science Foundation (NSF), Division of Astronomical Sciences under Contract No. AST-0950945 to the NSF’s National Optical-Infrared Astronomy Research Laboratory; the Science and Technology Facilities Council of the United Kingdom; the Gordon and Betty Moore Foundation; the Heising-Simons Foundation; the French Alternative Energies and Atomic Energy Commission (CEA); the National Council of Humanities, Science and Technology of Mexico (CONAHCYT); the Ministry of Science and Innovation of Spain (MICINN), and by the DESI Member Institutions: www.desi.lbl.gov/collaborating-institutions. The DESI collaboration is honored to be permitted to conduct scientific research on I’oligam Du’ag (Kitt Peak), a mountain with particular significance to the Tohono O’odham Nation. Any opinions, findings, and conclusions or recommendations expressed in this material are those of the author(s) and do not necessarily reflect the views of the U.S. National Science Foundation, the U.S. Department of Energy, or any of the listed funding agencies.

Data files are not copied here. `python3 fetch_data.py` downloads them from the pinned links above and checks their SHA-256.

## How it was done

Prepared with AI assistance.

## Run it

The automated replay does not rerun `c0_controls`, `c9_citations` or `grid_convergence`; their saved outputs remain the record. See [`VALIDATION.md`](VALIDATION.md) for the requirements and scope of those checks.

```sh
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 -m unittest test_validation.py   # the comparison rejects known failure modes
python3 reproduce.py --all    # full suite; required for release verification
```

Runtime: about 2 minutes without --all, after a download of about 95 MB of pinned data; with --all, about 70 minutes more on 4 cores to rebuild the 14 likelihood grids (0.66 GB of disk) before the posteriors are recomputed.

Every published file is checked against `MANIFEST.txt` (SHA-256) before and after the run. The run works in a copy under `_runs/`, so the saved outputs are never overwritten. Without `--all` the slow sampler checks are skipped. A passing replay does not change any claim result above.

## Cite

Cite the original paper first. To cite this check, use `CITATION.cff`. Code: BSD-3-Clause. Text: CC BY 4.0.
